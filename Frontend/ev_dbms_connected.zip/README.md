# EV Thermal Management: run guide

## 1. Database (pgAdmin)
1. In pgAdmin create a database named `ev_telemetry_db`.
2. Right-click it > **Query Tool** > open `databse/pgadmin_setup.sql` > press **F5**.
   This creates the tables, the change log, its triggers and the views. It resets all data.
3. Put your CSV (`ev_charging_patterns_thermal_sensors (2).csv`) in the project root, then load it:
   `python backend/etl_pipeline.py`
   No CSV yet? Run `databse/demo_seed.sql` in pgAdmin for 20,000 synthetic sessions.
4. Check in pgAdmin: `SELECT * FROM v_model_stats;`

## 2. Backend + page
```
cd ev_dbms
venv\Scripts\activate
pip install -r backend\requirements.txt
set DATABASE_URL=postgresql://postgres:YOUR_PASSWORD@localhost:5432/ev_telemetry_db
python backend\app.py
```
Open http://localhost:5000. Use the same `DATABASE_URL` when you run the ETL if your password is not `postgres`.

## How changes are shown separately
Every session added or deleted (from the page or from pgAdmin) is written to `session_changes` by database
triggers. The Statistics page shows live totals in one table and the changes in another; the Edit page lists
them as Added / Deleted. In pgAdmin: `SELECT * FROM session_changes ORDER BY change_id DESC;`
Bulk loads (ETL, demo seed) are not logged: they set `ev.bulk_load = 'on'`.
