-- ==============================================================================
-- OPTIONAL DEMO DATA (synthetic, NOT your CSV). Run in pgAdmin after pgadmin_setup.sql
-- if you just want to see the dashboard working. Use backend/etl_pipeline.py for the
-- real dataset. Change 20000 below to load more or fewer sessions.
-- ==============================================================================
SET ev.bulk_load = 'on';   -- do not write these rows to the change log

INSERT INTO charging_sessions (model_id, user_id, charging_station_id, station_location,
    charger_type, user_type, start_time, end_time, charging_duration_hours,
    energy_consumed_kwh, charging_rate_kw, charging_cost_usd, time_of_day, day_of_week,
    soc_start_pct, soc_end_pct, distance_driven_km, ambient_temp_c, vehicle_age_years)
SELECT 1 + (g % 5), 'User_' || g, 'Station_' || (1 + g % 500),
       (ARRAY['Houston','San Francisco','Los Angeles','Chicago','New York'])[1 + g % 5],
       CASE WHEN g % 3 = 0 THEN 'Level 2' ELSE 'DC Fast Charger' END,
       (ARRAY['Commuter','Casual Driver','Long-Distance Traveler'])[1 + g % 3],
       ts - make_interval(hours => 2), ts, 1 + random() * 3, 20 + random() * 50,
       10 + random() * 40, 5 + random() * 30,
       (ARRAY['Morning','Afternoon','Evening','Night'])[1 + g % 4],
       (ARRAY['Monday','Tuesday','Wednesday','Thursday','Friday','Saturday','Sunday'])[1 + g % 7],
       10 + random() * 30, 60 + random() * 35, 20 + random() * 250, 5 + random() * 30, random() * 10
FROM (SELECT g, TIMESTAMP '2024-01-01' + make_interval(mins => g) AS ts
      FROM generate_series(1, 20000) g) s;

INSERT INTO thermal_telemetry (session_id, model_id, pack_voltage_v, battery_current_a,
    battery_temp_min_c, battery_temp_max_c, battery_temp_avg_c, coolant_flow_rate_lpm,
    coolant_inlet_temp_c, coolant_outlet_temp_c)
SELECT session_id, model_id, 350 + random() * 60, 30 + random() * 80,
       t - 2 - random() * 3, t + 2 + random() * 6, t, 8 + random() * 12, 18 + random() * 6, 24 + random() * 8
FROM (SELECT session_id, model_id, 18 + random() * 16 + (model_id % 3) AS t FROM charging_sessions) x;

INSERT INTO digital_twin_metrics (session_id, model_id, sync_status, predicted_max_temp_c,
    predicted_soh_pct, sync_latency_ms)
SELECT cs.session_id, cs.model_id, 'Synchronized', tt.battery_temp_max_c + 1,
       76 + random() * 22, 80 + random() * 100
FROM charging_sessions cs JOIN thermal_telemetry tt USING (session_id);

RESET ev.bulk_load;
SELECT * FROM v_fleet_kpis;
