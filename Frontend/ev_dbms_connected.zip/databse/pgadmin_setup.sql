-- ==============================================================================
-- EV THERMAL MANAGEMENT  -  PostgreSQL setup for pgAdmin 4   (PostgreSQL 14+)
--
-- HOW TO RUN IN pgAdmin
--   1. Create a database called  ev_telemetry_db   (Databases > Create > Database).
--   2. Right-click ev_telemetry_db > Query Tool, open this file, press F5.
--   3. Load the data: python backend/etl_pipeline.py   (or run databse/demo_seed.sql).
--
-- WARNING: this script DROPS and recreates every table, so it resets the data.
-- Keep the percent sign out of this file; the Python ETL runs it as raw SQL.
-- ==============================================================================

DROP VIEW  IF EXISTS v_model_changes, v_fleet_kpis, v_model_stats, v_session_facts CASCADE;
DROP TABLE IF EXISTS session_changes, digital_twin_metrics, thermal_telemetry, charging_sessions, vehicle_models CASCADE;
DROP FUNCTION IF EXISTS fn_log_session_insert() CASCADE;
DROP FUNCTION IF EXISTS fn_log_session_delete() CASCADE;

-- 1. PARENT TABLE ---------------------------------------------------------------
CREATE TABLE vehicle_models (
    model_id SERIAL PRIMARY KEY,
    model_name VARCHAR(100) NOT NULL UNIQUE,
    default_battery_capacity_kwh NUMERIC(8, 2) NOT NULL,
    vehicle_class VARCHAR(50) DEFAULT 'Passenger EV',
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

INSERT INTO vehicle_models (model_name, default_battery_capacity_kwh) VALUES
    ('BMW i3', 108.46), ('Chevy Bolt', 75.00), ('Hyundai Kona', 100.00),
    ('Nissan Leaf', 50.00), ('Tesla Model 3', 82.00);

-- 2. CHILD TABLES ---------------------------------------------------------------
CREATE TABLE charging_sessions (
    session_id SERIAL PRIMARY KEY,
    model_id INT NOT NULL,
    user_id VARCHAR(50) NOT NULL,
    charging_station_id VARCHAR(50) NOT NULL,
    station_location VARCHAR(100) NOT NULL,
    charger_type VARCHAR(50) NOT NULL,
    user_type VARCHAR(50) NOT NULL,
    start_time TIMESTAMP WITHOUT TIME ZONE NOT NULL,
    end_time TIMESTAMP WITHOUT TIME ZONE NOT NULL,
    charging_duration_hours NUMERIC(6, 3) NOT NULL,
    energy_consumed_kwh NUMERIC(8, 3) NOT NULL,
    charging_rate_kw NUMERIC(6, 3) NOT NULL,
    charging_cost_usd NUMERIC(8, 3) NOT NULL,
    time_of_day VARCHAR(30),
    day_of_week VARCHAR(30),
    soc_start_pct NUMERIC(5, 2) NOT NULL,
    soc_end_pct NUMERIC(5, 2) NOT NULL,
    distance_driven_km NUMERIC(8, 2) NOT NULL,
    ambient_temp_c NUMERIC(5, 2) NOT NULL,
    vehicle_age_years NUMERIC(4, 1) NOT NULL,
    CONSTRAINT fk_sessions_model FOREIGN KEY (model_id)
        REFERENCES vehicle_models(model_id) ON DELETE CASCADE
);

CREATE TABLE thermal_telemetry (
    telemetry_id SERIAL PRIMARY KEY,
    session_id INT UNIQUE NOT NULL,
    model_id INT NOT NULL,
    pack_voltage_v NUMERIC(6, 2) NOT NULL,
    battery_current_a NUMERIC(6, 2) NOT NULL,
    battery_temp_min_c NUMERIC(5, 2) NOT NULL,
    battery_temp_max_c NUMERIC(5, 2) NOT NULL,
    battery_temp_avg_c NUMERIC(5, 2) NOT NULL,
    coolant_flow_rate_lpm NUMERIC(5, 2) NOT NULL,
    coolant_inlet_temp_c NUMERIC(5, 2) NOT NULL,
    coolant_outlet_temp_c NUMERIC(5, 2) NOT NULL,
    CONSTRAINT fk_telemetry_session FOREIGN KEY (session_id)
        REFERENCES charging_sessions(session_id) ON DELETE CASCADE,
    CONSTRAINT fk_telemetry_model FOREIGN KEY (model_id)
        REFERENCES vehicle_models(model_id) ON DELETE CASCADE
);

CREATE TABLE digital_twin_metrics (
    twin_id SERIAL PRIMARY KEY,
    session_id INT UNIQUE NOT NULL,
    model_id INT NOT NULL,
    sync_status VARCHAR(50) NOT NULL,
    predicted_max_temp_c NUMERIC(5, 2) NOT NULL,
    predicted_soh_pct NUMERIC(5, 2) NOT NULL,
    sync_latency_ms NUMERIC(6, 2) NOT NULL,
    CONSTRAINT fk_twin_session FOREIGN KEY (session_id)
        REFERENCES charging_sessions(session_id) ON DELETE CASCADE,
    CONSTRAINT fk_twin_model FOREIGN KEY (model_id)
        REFERENCES vehicle_models(model_id) ON DELETE CASCADE
);

CREATE INDEX idx_sessions_model_id     ON charging_sessions(model_id);
CREATE INDEX idx_sessions_user_id      ON charging_sessions(user_id);
CREATE INDEX idx_sessions_charger_type ON charging_sessions(charger_type);
CREATE INDEX idx_telemetry_model_id    ON thermal_telemetry(model_id);
CREATE INDEX idx_twin_model_id         ON digital_twin_metrics(model_id);

-- 3. CHANGE LOG: every session added or deleted after the data was loaded -----------
-- No foreign keys on purpose: a DELETE entry must outlive the session it describes.
CREATE TABLE session_changes (
    change_id BIGSERIAL PRIMARY KEY,
    change_type VARCHAR(6) NOT NULL CHECK (change_type IN ('INSERT', 'DELETE')),
    session_id INT NOT NULL,
    model_id INT NOT NULL,
    user_id VARCHAR(50),
    energy_consumed_kwh NUMERIC(8, 3),
    charging_duration_hours NUMERIC(6, 3),
    charging_rate_kw NUMERIC(6, 3),
    battery_temp_avg_c NUMERIC(5, 2),
    predicted_soh_pct NUMERIC(5, 2),
    changed_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX idx_changes_changed_at ON session_changes(changed_at DESC);

-- Bulk loads (ETL, demo seed) switch logging off for their own session with:
--     SET ev.bulk_load = 'on';
CREATE FUNCTION fn_log_session_insert() RETURNS trigger AS $$
BEGIN
    IF current_setting('ev.bulk_load', true) = 'on' THEN RETURN NULL; END IF;
    INSERT INTO session_changes (change_type, session_id, model_id, user_id,
        energy_consumed_kwh, charging_duration_hours, charging_rate_kw,
        battery_temp_avg_c, predicted_soh_pct)
    SELECT 'INSERT', NEW.session_id, NEW.model_id, NEW.user_id,
           NEW.energy_consumed_kwh, NEW.charging_duration_hours, NEW.charging_rate_kw,
           (SELECT tt.battery_temp_avg_c FROM thermal_telemetry tt WHERE tt.session_id = NEW.session_id),
           (SELECT dt.predicted_soh_pct FROM digital_twin_metrics dt WHERE dt.session_id = NEW.session_id);
    RETURN NULL;
END;
$$ LANGUAGE plpgsql;

-- Deferred, so it fires at COMMIT after the thermal and digital-twin rows exist.
CREATE CONSTRAINT TRIGGER trg_log_session_insert
    AFTER INSERT ON charging_sessions
    DEFERRABLE INITIALLY DEFERRED
    FOR EACH ROW EXECUTE FUNCTION fn_log_session_insert();

CREATE FUNCTION fn_log_session_delete() RETURNS trigger AS $$
BEGIN
    IF current_setting('ev.bulk_load', true) = 'on' THEN RETURN OLD; END IF;
    INSERT INTO session_changes (change_type, session_id, model_id, user_id,
        energy_consumed_kwh, charging_duration_hours, charging_rate_kw,
        battery_temp_avg_c, predicted_soh_pct)
    SELECT 'DELETE', OLD.session_id, OLD.model_id, OLD.user_id,
           OLD.energy_consumed_kwh, OLD.charging_duration_hours, OLD.charging_rate_kw,
           (SELECT tt.battery_temp_avg_c FROM thermal_telemetry tt WHERE tt.session_id = OLD.session_id),
           (SELECT dt.predicted_soh_pct FROM digital_twin_metrics dt WHERE dt.session_id = OLD.session_id);
    RETURN OLD;
END;
$$ LANGUAGE plpgsql;

-- BEFORE DELETE, so the child rows still exist when we read them (before the cascade).
CREATE TRIGGER trg_log_session_delete
    BEFORE DELETE ON charging_sessions
    FOR EACH ROW EXECUTE FUNCTION fn_log_session_delete();

-- 4. VIEWS (in pgAdmin: right-click a view > View/Edit Data > All Rows) -------------
CREATE VIEW v_session_facts AS
SELECT cs.session_id, cs.model_id, vm.model_name, cs.user_id, cs.charger_type,
       cs.energy_consumed_kwh, cs.charging_duration_hours, cs.charging_rate_kw,
       tt.battery_temp_min_c, tt.battery_temp_max_c, tt.battery_temp_avg_c,
       dt.predicted_soh_pct, dt.sync_latency_ms
FROM charging_sessions cs
INNER JOIN vehicle_models vm       ON vm.model_id = cs.model_id
INNER JOIN thermal_telemetry tt    ON tt.session_id = cs.session_id
INNER JOIN digital_twin_metrics dt ON dt.session_id = cs.session_id;

-- Live per-model statistics (the Statistics table). risk_pct = share of sessions with
-- SOH under 85; avg_rise_c = average in-session temperature spread (max minus min).
CREATE VIEW v_model_stats AS
SELECT model_name,
       COUNT(*)                                                        AS count_sessions,
       ROUND(SUM(energy_consumed_kwh), 2)                              AS sum_energy_kwh,
       ROUND(AVG(energy_consumed_kwh), 2)                              AS avg_energy_kwh,
       ROUND((PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY energy_consumed_kwh))::NUMERIC, 2) AS median_energy_kwh,
       ROUND(AVG(charging_duration_hours), 2)                          AS avg_duration_hrs,
       ROUND(AVG(charging_rate_kw), 2)                                 AS avg_rate_kw,
       ROUND(AVG(battery_temp_avg_c), 2)                               AS avg_temp_c,
       ROUND((PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY battery_temp_avg_c))::NUMERIC, 2)  AS median_temp_c,
       ROUND(AVG(predicted_soh_pct), 2)                                AS avg_soh_pct,
       ROUND((PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY predicted_soh_pct))::NUMERIC, 2)   AS median_soh_pct,
       ROUND(100.0 * AVG((predicted_soh_pct < 85)::INT), 2)            AS risk_pct,
       ROUND(AVG(battery_temp_max_c - battery_temp_min_c), 2)          AS avg_rise_c,
       MAX(battery_temp_max_c)                                         AS peak_temp_c
FROM v_session_facts
GROUP BY model_name
ORDER BY model_name;

CREATE VIEW v_fleet_kpis AS
SELECT COUNT(*) AS total_sessions,
       ROUND(SUM(energy_consumed_kwh) / 1000.0, 2) AS total_energy_mwh,
       ROUND(AVG(battery_temp_avg_c), 2)           AS avg_battery_temp_c,
       ROUND(AVG(predicted_soh_pct), 2)            AS avg_soh_pct,
       ROUND(AVG(sync_latency_ms), 1)              AS avg_sync_latency_ms
FROM v_session_facts;

-- Changes, kept separate from the live statistics: one row per model.
CREATE VIEW v_model_changes AS
SELECT vm.model_name,
       COUNT(*) FILTER (WHERE sc.change_type = 'INSERT')                                 AS sessions_added,
       COUNT(*) FILTER (WHERE sc.change_type = 'DELETE')                                 AS sessions_deleted,
       COUNT(*) FILTER (WHERE sc.change_type = 'INSERT')
         - COUNT(*) FILTER (WHERE sc.change_type = 'DELETE')                             AS net_sessions,
       COALESCE(SUM(sc.energy_consumed_kwh) FILTER (WHERE sc.change_type = 'INSERT'), 0) AS energy_added_kwh,
       COALESCE(SUM(sc.energy_consumed_kwh) FILTER (WHERE sc.change_type = 'DELETE'), 0) AS energy_removed_kwh
FROM vehicle_models vm
LEFT JOIN session_changes sc ON sc.model_id = vm.model_id
GROUP BY vm.model_name
ORDER BY vm.model_name;

-- After loading data, try these in the Query Tool:
--   SELECT * FROM v_model_stats;     SELECT * FROM v_fleet_kpis;
--   SELECT * FROM session_changes ORDER BY change_id DESC;     SELECT * FROM v_model_changes;
