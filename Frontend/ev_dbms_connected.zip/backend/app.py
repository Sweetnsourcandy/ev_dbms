"""EV Thermal Management API (Flask + PostgreSQL).

Run:  python backend/app.py      then open  http://localhost:5000
DB:   set DATABASE_URL, e.g.  postgresql://postgres:YOUR_PASSWORD@localhost:5432/ev_telemetry_db
Every number on the dashboard comes from PostgreSQL (see databse/pgadmin_setup.sql).
"""
import os
from datetime import datetime, timedelta
from decimal import Decimal

from flask import Flask, jsonify, request, send_from_directory
from sqlalchemy import create_engine, text
from sqlalchemy.exc import SQLAlchemyError

DB_URL = os.environ.get("DATABASE_URL", "postgresql://postgres:postgres@localhost:5432/ev_telemetry_db")
if DB_URL.startswith("postgresql://"):  # SQLAlchemy 2.1 would pick psycopg3; requirements.txt installs psycopg2
    DB_URL = DB_URL.replace("postgresql://", "postgresql+psycopg2://", 1)
FRONTEND = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "Frontend"))
COST_PER_KWH = 0.45  # charging_cost_usd is NOT NULL, so new sessions get energy x this rate

app = Flask(__name__, static_folder=FRONTEND, static_url_path="")
try:
    from flask_cors import CORS
    CORS(app)  # lets the page work when opened from Live Server or file://
except ImportError:
    pass
engine = create_engine(DB_URL, pool_pre_ping=True)

# attribute chosen in the filter card -> column in v_session_facts (whitelist, never user text)
ATTRS = {"battery_temp_avg_c": "battery_temp_avg_c", "predicted_soh_pct": "predicted_soh_pct",
         "charging_rate_kw": "charging_rate_kw", "energy_consumed_kwh": "energy_consumed_kwh",
         "charging_duration_hours": "charging_duration_hours"}
# range checks for the insert form (same limits as the inputs on the page)
LIMITS = {"energy_consumed_kwh": (1, 200), "charging_duration_hours": (0.1, 24), "charging_rate_kw": (1, 350),
          "battery_temp_avg_c": (0, 65), "predicted_soh_pct": (50, 100), "coolant_flow_rate_lpm": (0, 40)}


def clean(v):
    return float(v) if isinstance(v, Decimal) else (v.isoformat() if isinstance(v, datetime) else v)


def rows(conn, sql, **params):
    return [{k: clean(v) for k, v in r._mapping.items()} for r in conn.execute(text(sql), params)]


def fail(msg, code=400):
    return jsonify(status="error", message=msg), code


@app.errorhandler(SQLAlchemyError)
def db_error(e):
    app.logger.exception(e)
    return fail("Database error. Is PostgreSQL running and DATABASE_URL correct? " + str(getattr(e, "orig", e)).strip(), 503)


# --------------------------------------------------------------------------- pages
@app.route("/")
def index():
    return send_from_directory(FRONTEND, "index.html")


@app.route("/api/health")
def health():
    with engine.connect() as c:
        n = c.execute(text("SELECT COUNT(*) FROM charging_sessions")).scalar()
    return jsonify(status="success", database="connected", sessions=n)


@app.route("/api/models")
def models():
    with engine.connect() as c:
        return jsonify(status="success", models=rows(c, "SELECT model_name, default_battery_capacity_kwh AS capacity_kwh, vehicle_class FROM vehicle_models ORDER BY model_name"))


# --------------------------------------------------------------------------- dashboard
def scope_sql(scope):
    """Return (CTE text, params, WHERE text). Full scope = every row; filtered = threshold + sampled row cap."""
    if scope.get("mode") != "filtered":
        return "SELECT * FROM v_session_facts", {}, ""
    col = ATTRS.get(scope.get("attribute"))
    if not col:
        raise ValueError("Unknown filter attribute.")
    op = ">" if scope.get("operator", "gt") == "gt" else "<"
    where = f"WHERE {col} {op} :thr"
    params = {"thr": float(scope.get("threshold", 0)), "lim": max(1, min(int(scope.get("row_limit", 10000)), 1000000))}
    # md5 ordering = a repeatable pseudo-random sample, so the cap does not just keep the oldest rows
    return f"SELECT * FROM v_session_facts {where} ORDER BY md5(session_id::text) LIMIT :lim", params, where


@app.route("/api/dashboard", methods=["POST"])
def dashboard():
    """One call returns KPIs + per-model stats for the chosen scope, plus the separate change summary."""
    scope = (request.get_json(silent=True) or {}).get("scope", {})
    try:
        base, params, where = scope_sql(scope)
    except (ValueError, TypeError) as e:
        return fail(str(e))
    cte = f"WITH base AS ({base})"
    with engine.connect() as c:
        matched = rows(c, f"SELECT COUNT(*) AS n FROM v_session_facts {where}", **{k: v for k, v in params.items() if k == "thr"})[0]["n"]
        kpis = rows(c, f"""{cte} SELECT COUNT(*) AS total_sessions, COALESCE(ROUND(SUM(energy_consumed_kwh)/1000.0, 2), 0) AS total_energy_mwh,
            ROUND(AVG(energy_consumed_kwh), 2) AS avg_energy_kwh, ROUND(AVG(battery_temp_avg_c), 2) AS avg_battery_temp_c,
            ROUND(AVG(predicted_soh_pct), 2) AS avg_soh_pct, ROUND(AVG(sync_latency_ms), 1) AS avg_sync_latency_ms FROM base""", **params)[0]
        models_ = rows(c, f"""{cte} SELECT model_name, COUNT(*) AS count_sessions, ROUND(SUM(energy_consumed_kwh), 2) AS sum_energy_kwh,
            ROUND(AVG(energy_consumed_kwh), 2) AS avg_energy_kwh,
            ROUND((PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY energy_consumed_kwh))::NUMERIC, 2) AS median_energy_kwh,
            ROUND(AVG(charging_duration_hours), 2) AS avg_duration_hrs, ROUND(AVG(charging_rate_kw), 2) AS avg_rate_kw,
            ROUND(AVG(battery_temp_avg_c), 2) AS avg_temp_c,
            ROUND((PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY battery_temp_avg_c))::NUMERIC, 2) AS median_temp_c,
            ROUND(AVG(predicted_soh_pct), 2) AS avg_soh_pct,
            ROUND((PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY predicted_soh_pct))::NUMERIC, 2) AS median_soh_pct,
            ROUND(100.0 * AVG((predicted_soh_pct < 85)::INT), 2) AS risk_pct,
            ROUND(AVG(battery_temp_max_c - battery_temp_min_c), 2) AS avg_rise_c, MAX(battery_temp_max_c) AS peak_temp_c
            FROM base GROUP BY model_name ORDER BY model_name""", **params)
        return jsonify(status="success", scope={**scope, "matched_rows": matched}, kpis=kpis, models=models_, changes=change_summary(c))


# --------------------------------------------------------------------------- changes (kept separate)
def change_summary(c):
    s = rows(c, """SELECT COUNT(*) FILTER (WHERE change_type='INSERT') AS added, COUNT(*) FILTER (WHERE change_type='DELETE') AS deleted,
        (SELECT COUNT(*) FROM charging_sessions) AS current_total FROM session_changes""")[0]
    s["net"] = s["added"] - s["deleted"]
    s["baseline_total"] = s["current_total"] - s["net"]
    return {"summary": s, "by_model": rows(c, "SELECT * FROM v_model_changes")}


@app.route("/api/changes")
def changes():
    limit = max(1, min(request.args.get("limit", 30, type=int), 200))
    with engine.connect() as c:
        recent = rows(c, """SELECT sc.change_id, sc.change_type, sc.session_id, vm.model_name, sc.user_id, sc.energy_consumed_kwh,
            sc.battery_temp_avg_c, sc.predicted_soh_pct, sc.changed_at FROM session_changes sc
            JOIN vehicle_models vm ON vm.model_id = sc.model_id ORDER BY sc.change_id DESC LIMIT :n""", n=limit)
        return jsonify(status="success", recent=recent, **change_summary(c))


# --------------------------------------------------------------------------- insert / delete
@app.route("/api/sessions", methods=["POST"])
def add_session():
    p = request.get_json(silent=True) or {}
    name = str(p.get("model_name", "")).strip()
    try:
        v = {k: float(p[k]) for k in LIMITS}
    except (KeyError, TypeError, ValueError):
        return fail("Fill in every numeric field with a number.")
    for k, (lo, hi) in LIMITS.items():
        if not lo <= v[k] <= hi:
            return fail(f"{k} must be between {lo} and {hi}.")
    charger = p.get("charger_type") if p.get("charger_type") in ("DC Fast Charger", "Level 2") else "DC Fast Charger"
    now = datetime.now()
    tod = "Morning" if now.hour < 12 else "Afternoon" if now.hour < 17 else "Evening" if now.hour < 21 else "Night"
    with engine.begin() as c:  # one transaction: all three tables or none
        mid = c.execute(text("SELECT model_id FROM vehicle_models WHERE model_name = :n"), {"n": name}).scalar()
        if mid is None:
            return fail(f"'{name}' is not in vehicle_models. Pick an existing model.")
        sid = c.execute(text("SELECT nextval('charging_sessions_session_id_seq')")).scalar()
        uid = str(p.get("user_id") or "").strip()[:50] or f"USR-{sid}"
        c.execute(text("""INSERT INTO charging_sessions (session_id, model_id, user_id, charging_station_id, station_location, charger_type,
            user_type, start_time, end_time, charging_duration_hours, energy_consumed_kwh, charging_rate_kw, charging_cost_usd,
            time_of_day, day_of_week, soc_start_pct, soc_end_pct, distance_driven_km, ambient_temp_c, vehicle_age_years)
            VALUES (:sid, :mid, :uid, 'STN-501', 'Dashboard entry', :ch, 'Fleet Driver', :st, :en, :dur, :e, :r, :cost,
            :tod, :dow, 22, 85, 160, 24.5, 2.5)"""),
                  {"sid": sid, "mid": mid, "uid": uid, "ch": charger, "st": now - timedelta(hours=v["charging_duration_hours"]), "en": now,
                   "dur": v["charging_duration_hours"], "e": v["energy_consumed_kwh"], "r": v["charging_rate_kw"],
                   "cost": round(v["energy_consumed_kwh"] * COST_PER_KWH, 2), "tod": tod, "dow": now.strftime("%A")})
        t = v["battery_temp_avg_c"]
        c.execute(text("""INSERT INTO thermal_telemetry (session_id, model_id, pack_voltage_v, battery_current_a, battery_temp_min_c,
            battery_temp_max_c, battery_temp_avg_c, coolant_flow_rate_lpm, coolant_inlet_temp_c, coolant_outlet_temp_c)
            VALUES (:sid, :mid, 398.5, :cur, :tmin, :tmax, :t, :cool, 21.5, 29.2)"""),
                  {"sid": sid, "mid": mid, "cur": round(v["charging_rate_kw"] * 1000 / 398.5, 2), "tmin": round(t - 2.5, 2),
                   "tmax": round(t + 3.0, 2), "t": t, "cool": v["coolant_flow_rate_lpm"]})
        c.execute(text("""INSERT INTO digital_twin_metrics (session_id, model_id, sync_status, predicted_max_temp_c, predicted_soh_pct, sync_latency_ms)
            VALUES (:sid, :mid, 'Synchronized', :pm, :soh, 112.4)"""), {"sid": sid, "mid": mid, "pm": round(t + 3.8, 2), "soh": v["predicted_soh_pct"]})
    return jsonify(status="success", message=f"Added session {sid} ({uid}) for {name}.", session_id=sid, user_id=uid)


@app.route("/api/sessions", methods=["DELETE"])
def delete_session():
    uid = str((request.get_json(silent=True) or {}).get("user_id", "")).strip()
    if not uid:
        return fail("Enter a driver user ID.")
    with engine.begin() as c:  # removes the newest session of this user; child rows cascade; trigger logs it
        gone = rows(c, """WITH t AS (SELECT session_id FROM charging_sessions WHERE user_id = :u ORDER BY session_id DESC LIMIT 1)
            DELETE FROM charging_sessions cs USING t WHERE cs.session_id = t.session_id RETURNING cs.session_id, cs.model_id""", u=uid)
        if not gone:
            return fail(f"No session found for user ID '{uid}'.", 404)
        left = c.execute(text("SELECT COUNT(*) FROM charging_sessions WHERE user_id = :u"), {"u": uid}).scalar()
    msg = f"Deleted session {gone[0]['session_id']} for {uid}." + (f" {left} more session(s) for this user remain." if left else "")
    return jsonify(status="success", message=msg, session_id=gone[0]["session_id"])


if __name__ == "__main__":
    app.run(host="127.0.0.1", port=5000, debug=True)
