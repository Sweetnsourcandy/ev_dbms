/* EV Thermal Management dashboard. Every number comes from the Flask API, which reads PostgreSQL. */
const $ = id => document.getElementById(id);
const API = location.port === '5000' ? '' : 'http://localhost:5000'; // Flask serves this page on :5000; Live Server/file:// call it directly
const fmt = (n, d = 0) => n == null ? '–' : Number(n).toLocaleString('en-US', { minimumFractionDigits: d, maximumFractionDigits: d });
const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const STOPS = [[112, 150, 205], [122, 172, 170], [135, 182, 140], [205, 190, 120], [215, 150, 110], [200, 105, 105]];
function heat(x) { x = Math.max(0, Math.min(1, x)); const p = x * 5, i = Math.floor(p), f = p - i, a = STOPS[i], b = STOPS[Math.min(i + 1, 5)]; return `rgb(${a.map((v, k) => Math.round(v + (b[k] - v) * f)).join(',')})`; }
// colour position 0..1 within the data range; values within 5 percent of each other count as equal, so tiny gaps are not shown as big ones
const norm = (v, vals) => { const lo = Math.min(...vals), hi = Math.max(...vals); return (hi - lo) <= Math.abs(hi) * 0.05 ? 0.5 : (v - lo) / (hi - lo); };
const short = n => n.split(' ').slice(1).join(' ') || n;

const T = { filter: ['Choose a data scope', 'Pick the full database or a filtered sample. This sets what every other view shows.'], overview: ['Fleet thermal overview', 'How hot each model runs, how fast it charges, and where battery health is at risk.'], insert: ['Edit telemetry', 'Add new charging sessions or remove one by driver ID. Changes are saved to PostgreSQL.'], calc: ['Model statistics', 'Per-model aggregates from the joined vehicle and session tables.'] };
const NAV = [['filter', 'Scope', 'Full or filtered data', 'rgb(112,150,205)'], ['overview', 'Overview', 'Fleet thermal KPIs', 'rgb(135,182,140)'], ['insert', 'Edit telemetry', 'Add or delete sessions', 'rgb(205,190,120)'], ['calc', 'Statistics', 'Per-model table', 'rgb(200,105,105)']];
const COLS = [['model_name', 'Model'], ['count_sessions', 'Sessions'], ['sum_energy_kwh', 'Energy sum (kWh)'], ['avg_energy_kwh', 'Avg energy'], ['median_energy_kwh', 'Median energy'], ['avg_duration_hrs', 'Avg hours'], ['avg_rate_kw', 'Avg kW'], ['avg_temp_c', 'Avg temp °C'], ['median_temp_c', 'Median temp °C'], ['avg_soh_pct', 'Avg SOH %'], ['median_soh_pct', 'Median SOH %']];
const FIELDS = [['energy_consumed_kwh', 'Energy (kWh)', 46.8, .1], ['charging_duration_hours', 'Duration (hours)', 2.25, .05], ['charging_rate_kw', 'Rate (kW)', 28.4, .1], ['battery_temp_avg_c', 'Core temp (°C)', 26.3, .1], ['predicted_soh_pct', 'Predicted SOH (%)', 91.2, .1], ['coolant_flow_rate_lpm', 'Coolant flow (L/min)', 14.8, .1]];
const CHARTS = [['c1', 'risk_pct', '%'], ['c2', 'avg_rise_c', ' °C'], ['c3', 'avg_rate_kw', ' kW'], ['c4', 'peak_temp_c', ' °C']];

let page = 'filter', ready = false, scope = { mode: 'full' }, scopeTxt = '', D = null, CH = null, sortK = null, sortD = 1, charts = {};

/* ---------- API ---------- */
function showErr(msg) { const e = $('err'); e.textContent = msg || ''; e.style.display = msg ? 'block' : 'none'; }
function setConn(ok, info) { $('fDb').textContent = ok ? 'PostgreSQL ' + (info || 'connected') : 'Offline'; }
async function api(path, method = 'GET', body) {
  let r;
  try { r = await fetch(API + path, { method, headers: { 'Content-Type': 'application/json' }, body: body ? JSON.stringify(body) : undefined }); }
  catch (e) { setConn(false); throw new Error('Cannot reach the backend. Start it with: python backend/app.py'); }
  const j = await r.json().catch(() => ({}));
  if (!r.ok || j.status === 'error') throw new Error(j.message || 'Request failed (HTTP ' + r.status + ')');
  return j;
}
async function init() {
  go('filter');
  try {
    const h = await api('/api/health'); setConn(true, fmt(h.sessions) + ' rows'); $('bigRows').textContent = fmt(h.sessions); $('fRows').textContent = fmt(h.sessions) + ' rows'; showErr('');
    const m = await api('/api/models'); $('iM').innerHTML = m.models.map(x => `<option value="${esc(x.model_name)}">${esc(x.model_name)} (${fmt(x.capacity_kwh, 2)} kWh)</option>`).join('');
    $('iF').innerHTML = FIELDS.map(([k, l, v, s]) => `<div><label for="i_${k}">${l}</label><input id="i_${k}" type="number" step="${s}" value="${v}" required></div>`).join('');
  } catch (e) { showErr(e.message); }
}

/* ---------- navigation and scope ---------- */
function buildNav() { $('nav').innerHTML = NAV.map(([k, a, b, c]) => `<button id="n-${k}" style="--dot:${c}" ${k !== 'filter' && !ready ? 'disabled' : ''} onclick="go('${k}')"><b></b>${a}<small>${b}</small></button>`).join(''); $('n-' + page).classList.add('on'); }
function go(p) {
  page = p; document.querySelectorAll('.view').forEach(v => v.classList.remove('on')); $('v-' + p).classList.add('on');
  $('h1').textContent = T[p][0]; $('sub').textContent = T[p][1]; buildNav();
  if (!ready) return;
  if (p === 'insert') loadFeed();
  render();
}
function pick(m) { scope.mode = m; $('scFull').classList.toggle('sel', m === 'full'); $('scFilt').classList.toggle('sel', m === 'filtered'); }
async function apply() {
  scope = scope.mode === 'full' ? { mode: 'full' } : { mode: 'filtered', attribute: $('fAttr').value, operator: $('fOp').value, threshold: +$('fVal').value, row_limit: +$('fLim').value };
  try { await loadDash(); ready = true; showErr(''); go('overview'); } catch (e) { showErr(e.message); }
}
async function loadDash() {
  D = await api('/api/dashboard', 'POST', { scope }); CH = D.changes; setConn(true);
  scopeTxt = scope.mode === 'full' ? 'All sessions, no filter' : `${$('fAttr').selectedOptions[0].text} ${scope.operator === 'gt' ? '>' : '<'} ${scope.threshold}: ${fmt(D.scope.matched_rows)} rows match, ${fmt(D.kpis.total_sessions)} analysed`;
  if (ready) render();
}
async function loadFeed() { const j = await api('/api/changes?limit=30'); CH = { summary: j.summary, by_model: j.by_model }; renderFeed(j.recent); if (page === 'calc') renderChanges(); }
async function refresh() { await Promise.all([loadDash(), loadFeed()]); }

/* ---------- render ---------- */
function render() {
  if (!D) return;
  const k = D.kpis, s = CH.summary;
  $('fRows').textContent = fmt(s.current_total) + ' rows'; $('fScope').textContent = scope.mode === 'full' ? 'Full database' : 'Filtered';
  if (page === 'overview') {
    $('bPill').textContent = scope.mode === 'full' ? 'FULL FLEET' : 'FILTERED'; $('bTxt').textContent = scopeTxt;
    $('k1').textContent = fmt(k.total_sessions); $('k2').textContent = fmt(k.total_energy_mwh, 1) + ' MWh';
    $('k3').textContent = k.avg_battery_temp_c == null ? '–' : fmt(k.avg_battery_temp_c, 2) + ' °C'; $('k4').textContent = k.avg_soh_pct == null ? '–' : fmt(k.avg_soh_pct, 2) + '%';
    $('k1d').textContent = `Database: ${fmt(s.current_total)} total, ${fmt(s.added)} added, ${fmt(s.deleted)} deleted since load`;
    renderBand(); CHARTS.forEach(([id, key, unit]) => drawChart(id, key, unit));
  }
  if (page === 'calc') { renderTable(); renderChanges(); }
}
function renderBand() {
  const M = [...D.models].sort((a, b) => a.avg_temp_c - b.avg_temp_c), t = M.map(m => m.avg_temp_c);
  if (!M.length) { $('scale').innerHTML = ''; ['tk0', 'tk2'].forEach(i => $(i).textContent = ''); return; }
  const span = Math.max(Math.max(...t) - Math.min(...t), 0.2), lo = Math.min(...t) - span * .3 - .1, hi = Math.max(...t) + span * .3 + .1;
  $('scale').innerHTML = M.map((m, i) => `<div class="mk ${i % 2 ? 'd' : 'u'}" style="left:${(m.avg_temp_c - lo) / (hi - lo) * 100}%"><span>${esc(short(m.model_name))}<em>${fmt(m.avg_temp_c, 2)}°</em></span></div>`).join('');
  $('tk0').textContent = fmt(lo, 1) + ' °C'; $('tk2').textContent = fmt(hi, 1) + ' °C';
}
function drawChart(id, key, unit) {
  if (typeof Chart === 'undefined') { showErr('Charts need internet access to load Chart.js from cdn.jsdelivr.net.'); return; }
  const vals = D.models.map(m => m[key]), cols = vals.map(v => heat(norm(v, vals))), labels = D.models.map(m => short(m.model_name));
  if (charts[id]) { const c = charts[id]; c.data.labels = labels; c.data.datasets[0].data = vals; c.data.datasets[0].backgroundColor = cols; c.update(); return; }
  const css = v => getComputedStyle(document.documentElement).getPropertyValue(v).trim();
  charts[id] = new Chart($(id), { type: 'bar', data: { labels, datasets: [{ data: vals, backgroundColor: cols, borderRadius: 8, borderSkipped: false }] },
    options: { maintainAspectRatio: false, plugins: { legend: { display: false }, tooltip: { callbacks: { label: c => fmt(c.parsed.y, 2) + unit } } },
      scales: { x: { ticks: { color: css('--mut') }, grid: { display: false } }, y: { beginAtZero: true, ticks: { color: css('--mut') }, grid: { color: css('--line') } } } } });
}
function tableRows() { const q = $('q').value.toLowerCase(); const R = D.models.filter(m => m.model_name.toLowerCase().includes(q)); if (sortK) R.sort((a, b) => (a[sortK] > b[sortK] ? 1 : -1) * sortD); return R; }
function renderTable() {
  const R = tableRows(), k = D.kpis;
  $('thr').innerHTML = COLS.map(([c, l]) => `<th onclick="sortBy('${c}')">${l} ${sortK === c ? (sortD > 0 ? '↑' : '↓') : ''}</th>`).join('');
  $('tb').innerHTML = R.map(m => `<tr>${COLS.map(([c]) => c === 'model_name' ? `<td class="h">${esc(m.model_name)}</td>` : c === 'count_sessions' || c === 'sum_energy_kwh' ? `<td>${fmt(m[c], c === 'count_sessions' ? 0 : 0)}</td>` : c.endsWith('temp_c') ? `<td class="h" style="color:${heat(norm(m[c], D.models.map(x => x[c])))}">${fmt(m[c], 2)}</td>` : `<td>${fmt(m[c], 2)}</td>`).join('')}</tr>`).join('');
  const w = c => { const n = D.models.reduce((a, m) => a + m.count_sessions, 0); return n ? D.models.reduce((a, m) => a + m[c] * m.count_sessions, 0) / n : null; }; // exact: weighted mean of means
  $('tf').innerHTML = `<tr><td>Whole scope</td><td>${fmt(k.total_sessions)}</td><td>${fmt(D.models.reduce((a, m) => a + m.sum_energy_kwh, 0))}</td><td>${fmt(k.avg_energy_kwh, 2)}</td><td>–</td><td>${fmt(w('avg_duration_hrs'), 2)}</td><td>${fmt(w('avg_rate_kw'), 2)}</td><td>${fmt(k.avg_battery_temp_c, 2)}</td><td>–</td><td>${fmt(k.avg_soh_pct, 2)}</td><td>–</td></tr>`;
  $('rc').textContent = `${R.length} of ${D.models.length} models`;
}
function sortBy(c) { sortD = sortK === c ? -sortD : 1; sortK = c; renderTable(); }
function renderChanges() {
  const s = CH.summary;
  $('chNote').textContent = `${fmt(s.baseline_total)} sessions at load, ${fmt(s.added)} added, ${fmt(s.deleted)} deleted, ${fmt(s.current_total)} now. The table above shows the current totals; this one shows only what changed.`;
  $('chr').innerHTML = ['Model', 'Added', 'Deleted', 'Net sessions', 'Energy added (kWh)', 'Energy removed (kWh)'].map(h => `<th class="nosort">${h}</th>`).join('');
  $('chb').innerHTML = CH.by_model.map(m => `<tr><td class="h">${esc(m.model_name)}</td><td>${fmt(m.sessions_added)}</td><td>${fmt(m.sessions_deleted)}</td><td class="h">${m.net_sessions > 0 ? '+' : ''}${fmt(m.net_sessions)}</td><td>${fmt(m.energy_added_kwh, 1)}</td><td>${fmt(m.energy_removed_kwh, 1)}</td></tr>`).join('');
}
function renderFeed(recent) {
  const s = CH.summary;
  $('chSum').innerHTML = `<span style="color:var(--c1)">Added ${fmt(s.added)}</span><span style="color:var(--c4)">Deleted ${fmt(s.deleted)}</span><span>Net ${s.net > 0 ? '+' : ''}${fmt(s.net)}</span>`;
  $('feed').innerHTML = recent.length ? recent.map(r => `<div><span><span class="tag ${r.change_type === 'INSERT' ? 'add' : 'del'}">${r.change_type === 'INSERT' ? 'Added' : 'Deleted'}</span> Session ${r.session_id}, ${esc(r.model_name)}<small>${esc(r.user_id)} · ${fmt(r.energy_consumed_kwh, 1)} kWh · ${fmt(r.battery_temp_avg_c, 1)} °C · SOH ${fmt(r.predicted_soh_pct, 1)}%</small></span><small>${new Date(r.changed_at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</small></div>`).join('') : '<div class="empty">No changes yet. Add or delete a session.</div>';
}

/* ---------- insert / delete / export ---------- */
async function addRec(e) {
  e.preventDefault(); const o = $('iMsg'), body = { model_name: $('iM').value, charger_type: $('iC').value, user_id: $('iU').value };
  FIELDS.forEach(([k]) => body[k] = $('i_' + k).value);
  try { const j = await api('/api/sessions', 'POST', body); o.className = 'msg ok'; o.textContent = j.message; $('iU').value = ''; await refresh(); }
  catch (err) { o.className = 'msg er'; o.textContent = err.message; }
}
async function delRec(e) {
  e.preventDefault(); const o = $('dMsg');
  try { const j = await api('/api/sessions', 'DELETE', { user_id: $('dU').value }); o.className = 'msg ok'; o.textContent = j.message; await refresh(); }
  catch (err) { o.className = 'msg er'; o.textContent = err.message; }
}
function exportCSV() {
  if (!D) return; const R = tableRows();
  const csv = [COLS.map(c => c[1]).join(',')].concat(R.map(m => COLS.map(([k]) => k === 'model_name' ? `"${m.model_name}"` : m[k]).join(','))).join('\n');
  const a = document.createElement('a'); a.href = URL.createObjectURL(new Blob([csv], { type: 'text/csv' })); a.download = 'ev_model_statistics.csv'; a.click();
}
init();
